package in.it.educations.smsserver;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.KeyguardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.hardware.biometrics.BiometricPrompt;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.Handler;
import android.speech.RecognizerIntent;
import android.telephony.SmsManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Locale;
import java.util.Objects;

public class MainActivity extends AppCompatActivity {


    private static final int REQUEST_RECORD_PERMISSION = 101;
    private CancellationSignal cancellationSignal = null;
    Button btn;
    // create an authenticationCallback
    private BiometricPrompt.AuthenticationCallback authenticationCallback;


    void GetPermission()
    {
        if (ContextCompat.checkSelfPermission(getApplicationContext(), android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getApplicationContext(), android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION, android.Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.CALL_PHONE,Manifest.permission.SEND_SMS, Manifest.permission.RECORD_AUDIO}, 101);

        }
        ActivityCompat.requestPermissions
                (MainActivity.this,
                        new String[]{Manifest.permission.RECORD_AUDIO},
                        REQUEST_RECORD_PERMISSION);
    }
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case REQUEST_RECORD_PERMISSION:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                } else {
                    Toast.makeText(MainActivity.this, "Permission Denied!", Toast
                            .LENGTH_SHORT).show();
                }
        }
    }
    @RequiresApi(api = Build.VERSION_CODES.P)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        GetPermission();
        authenticationCallback = new BiometricPrompt.AuthenticationCallback() {

            @Override
            public void onAuthenticationError(
                    int errorCode, CharSequence errString)
            {
                super.onAuthenticationError(errorCode, errString);
                notifyUser("Authentication Error : " + errString);
            }

            @Override
            public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result)
            {
                super.onAuthenticationSucceeded(result);
                notifyUser("Authentication Succeeded");
                // or start a new Activity
                Intent i=new Intent(getApplicationContext(),VoiceActivity.class);
                startActivity(i);
            }
        };

        checkBiometricSupport();

                // create a biometric dialog on Click of button
               btn=  (Button) findViewById(R.id.start_authentication);
               btn.setOnClickListener(new View.OnClickListener() {
                    @RequiresApi(api = Build.VERSION_CODES.P)
                    @Override
                    public void onClick(View view)
                    {

                        BiometricPrompt biometricPrompt = new BiometricPrompt
                                .Builder(getApplicationContext())
                                .setTitle("IOT Door Lock")
                                .setSubtitle("")
                                .setDescription("")
                                .setNegativeButton("Cancel", getMainExecutor(), new DialogInterface.OnClickListener() {
                                    @Override
                                    public void
                                    onClick(DialogInterface dialogInterface, int i)
                                    {
                                        notifyUser("Authentication Cancelled");
                                    }
                                }).build();

                        // start the authenticationCallback in
                        // mainExecutor
                        biometricPrompt.authenticate(
                                getCancellationSignal(),
                                getMainExecutor(),
                                authenticationCallback);
                    }
                });
            }


            // it will be called when
            // authentication is cancelled by
            // the user
            private CancellationSignal getCancellationSignal()
            {
                cancellationSignal = new CancellationSignal();
                cancellationSignal.setOnCancelListener(
                        new CancellationSignal.OnCancelListener() {
                            @Override public void onCancel()
                            {
                                notifyUser("Authentication was Cancelled by the user");
                            }
                        });
                return cancellationSignal;
            }

            // it checks whether the
            // app the app has fingerprint
            // permission
            @RequiresApi(Build.VERSION_CODES.M)
            private Boolean checkBiometricSupport()
            {
                KeyguardManager keyguardManager = (KeyguardManager)getSystemService(Context.KEYGUARD_SERVICE);
                if (!keyguardManager.isDeviceSecure()) {
                    notifyUser("Fingerprint authentication has not been enabled in settings");
                    return false;
                }
                if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.USE_BIOMETRIC)!= PackageManager.PERMISSION_GRANTED) {
                    notifyUser("Fingerprint Authentication Permission is not enabled");
                    return false;
                }
                if (getPackageManager().hasSystemFeature(PackageManager.FEATURE_FINGERPRINT)) {
                    return true;
                }
                else
                    return true;
            }

            // this is a toast method which is responsible for
            // showing toast it takes a string as parameter
            private void notifyUser(String message)
            {
                Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
            }
        }


