package in.it.educations.smsserver;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Locale;
import java.util.Objects;

public class VoiceActivity extends AppCompatActivity {

    private ImageView iv_mic;
    private TextView tv_Speech_to_text;
    private static final int REQUEST_CODE_SPEECH_INPUT = 1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_voice);
        iv_mic = findViewById(R.id.iv_mic);
        tv_Speech_to_text = findViewById(R.id.tv_speech_to_text);
        iv_mic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                Intent intent
                        = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                        RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE,
                        Locale.getDefault());
                intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to text");

                try {
                    startActivityForResult(intent, REQUEST_CODE_SPEECH_INPUT);
                }
                catch (Exception e) {
                    Toast.makeText(VoiceActivity.this, " " + e.getMessage(),
                                    Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode,
                                    @Nullable Intent data)
    {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE_SPEECH_INPUT) {
            if (resultCode == RESULT_OK && data != null) {
                ArrayList<String> result = data.getStringArrayListExtra(
                        RecognizerIntent.EXTRA_RESULTS);
                tv_Speech_to_text.setText(
                        Objects.requireNonNull(result).get(0));
                try {
                 HttpGetRequest ht=new HttpGetRequest();
                 if(tv_Speech_to_text.getText().equals("door open")) {
                     ht.execute(URLPath.Path+"11").get();
                     Toast.makeText(VoiceActivity.this, " " + "11",
                             Toast.LENGTH_SHORT).show();
                 }
                 else if(tv_Speech_to_text.getText().equals("door close"))
                 {
                     ht.execute(URLPath.Path+"22").get();
                     Toast.makeText(VoiceActivity.this, " " + "22",
                             Toast.LENGTH_SHORT).show();
                 }
                 else if(tv_Speech_to_text.getText().equals("11"))
                 {
                     ht.execute(URLPath.Path+"22").get();
                     Toast.makeText(VoiceActivity.this, " " + "11",
                             Toast.LENGTH_SHORT).show();
                 }
                 else if(tv_Speech_to_text.getText().equals("22"))
                 {
                     ht.execute(URLPath.Path+"22").get();
                     Toast.makeText(VoiceActivity.this, " " + "22",
                             Toast.LENGTH_SHORT).show();
                 }

                 else
                 {
                     Toast.makeText(VoiceActivity.this, " " + "Invalid Voice Command",
                             Toast.LENGTH_SHORT).show();
                 }
                }
                catch (Exception ex)
                {
                    Toast.makeText(VoiceActivity.this, " " + ex.getMessage(),
                            Toast.LENGTH_SHORT).show();
                }

            }
        }
    }
}