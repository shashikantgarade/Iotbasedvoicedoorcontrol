package in.it.educations.smsserver;


public class URLPath {
    public static String Path = "http://192.168.159.71/IOTDemo/put.aspx?p=";

}